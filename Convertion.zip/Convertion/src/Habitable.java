
public interface Habitable {

      Vaisseau accueillirVaisseau(Vaisseau nouveauVaisseau);

}
