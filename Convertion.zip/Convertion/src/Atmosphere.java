public class Atmosphere {
    float tauxHelium;
    float tauxHydrogene;
    float tauxAzote;
    float tauxArgon;
    float tauxDioxydeDeCarbone;
    float tauxSodium;
    float tauxMethane;
}

